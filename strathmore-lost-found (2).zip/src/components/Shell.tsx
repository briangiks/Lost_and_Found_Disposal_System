import { Link, useRouterState } from "@tanstack/react-router";
import { LogOut, Bell, LayoutDashboard, Workflow, Mail, ClipboardList, Sun, Moon } from "lucide-react";
import type { ReactNode } from "react";
import strathmoreLogo from "@/assets/strathmore-logo.png";
import adminAvatar from "@/assets/admin-avatar.png";
import { useTheme } from "@/hooks/use-theme";

function Logo() {
  return (
    <Link to="/dashboard" className="flex items-center gap-3">
      <img src={strathmoreLogo} alt="Strathmore University" className="h-10 w-auto" />
      <div className="leading-tight">
        <div className="text-sm font-semibold text-brand-blue-dark">Strathmore University</div>
        <div className="text-[11px] text-muted-foreground -mt-0.5">Lost &amp; Found · Disposal System</div>
      </div>
    </Link>
  );
}

const navItems = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/disposal", label: "Disposal Workflow", icon: Workflow },
  { to: "/emails", label: "Email Preview", icon: Mail },
  { to: "/audit", label: "Audit Log", icon: ClipboardList },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { theme, toggle } = useTheme();
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="border-b bg-card sticky top-0 z-30">
        <div className="mx-auto max-w-7xl px-6 h-16 flex items-center justify-between gap-6">
          <Logo />
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((n) => {
              const active = pathname.startsWith(n.to);
              const Icon = n.icon;
              return (
                <Link
                  key={n.to}
                  to={n.to}
                  className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    active ? "bg-brand-blue text-white" : "text-foreground hover:bg-secondary"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {n.label}
                </Link>
              );
            })}
          </nav>
          <div className="flex items-center gap-2">
            <button
              onClick={toggle}
              className="p-2 rounded-md hover:bg-secondary text-foreground"
              aria-label="Toggle light/dark mode"
              title={theme === "dark" ? "Switch to light" : "Switch to dark"}
            >
              {theme === "dark" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            <button className="relative p-2 rounded-md hover:bg-secondary" aria-label="Notifications">
              <Bell className="w-5 h-5 text-foreground" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-brand-red rounded-full" />
            </button>
            <div className="hidden sm:flex items-center gap-2 pl-3 border-l">
              <div className="w-9 h-9 rounded-full bg-brand-red/10 border border-brand-red/20 flex items-center justify-center overflow-hidden">
                <img src={adminAvatar} alt="Admin" className="w-6 h-6 object-contain" />
              </div>
              <div className="text-sm leading-tight">
                <div className="font-medium">Admin</div>
                <div className="text-[11px] text-muted-foreground">L&amp;F Officer</div>
              </div>
              <Link to="/" className="ml-2 p-2 rounded-md hover:bg-secondary" aria-label="Sign out" title="Sign out">
                <LogOut className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </header>
      <main className="flex-1">{children}</main>
      <footer className="border-t bg-card">
        <div className="mx-auto max-w-7xl px-6 py-4 text-xs text-muted-foreground flex justify-between">
          <span>© Strathmore University · Lost &amp; Found Disposal System (Prototype)</span>
          <span>Laravel target build</span>
        </div>
      </footer>
    </div>
  );
}
