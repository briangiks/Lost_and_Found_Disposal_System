import type { DisposalStatus } from "@/lib/mock-data";
import { statusLabel } from "@/lib/mock-data";

const styles: Record<DisposalStatus, string> = {
  active: "bg-secondary text-secondary-foreground",
  due: "bg-destructive/10 text-destructive border border-destructive/30",
  notice_sent: "bg-warning/20 text-warning-foreground border border-warning/40",
  awaiting_pickup: "bg-brand-blue/10 text-brand-blue border border-brand-blue/30",
  donated: "bg-success/15 text-success-foreground border border-success/40",
};

export function StatusBadge({ status }: { status: DisposalStatus }) {
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium ${styles[status]}`}>
      {statusLabel[status]}
    </span>
  );
}
