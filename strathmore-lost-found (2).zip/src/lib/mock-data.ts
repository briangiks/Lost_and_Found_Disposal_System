export type DisposalStatus = "active" | "due" | "notice_sent" | "awaiting_pickup" | "donated";

// Item lifecycle age-band used in the registry table.
export type AgeBand = "fresh" | "within_quarter" | "due";

export interface LostItem {
  id: string;
  name: string;
  color: string;
  category: string;
  dateLost: string; // ISO
  location: string;
  markings: string;
  image: string;
  status: DisposalStatus;
  reporter?: string;
}

const today = new Date();
const daysAgo = (n: number) => {
  const d = new Date(today);
  d.setDate(d.getDate() - n);
  return d.toISOString().slice(0, 10);
};

// Card figures for the dashboard (mock — the L&F office keeps a much larger register
// than what this disposal system shows in the demo table).
export const TOTAL_IN_CUSTODY = 128;   // all currently unclaimed items in the register
export const TOTAL_TO_DISPOSE = 55;    // items that have reached / passed the 90-day window

// Strathmore-specific locations (used across the demo).
export const STRATH_LOCATIONS = [
  "MSB 13",
  "MSB 7",
  "LT 3",
  "LT 6",
  "Student Centre",
  "Oval Building",
  "STMB Basement",
  "F2",
  "F4",
  "F5",
  "Main Library",
  "STMB Library",
  "Gazebo",
  "Central Building Phase 1",
] as const;

export const MOCK_ITEMS: LostItem[] = [
  // Just past 90 days (max +3) → to be disposed (RED)
  { id: "LF-1042", name: "Black HP Laptop", color: "Black", category: "Electronics", dateLost: daysAgo(93), location: "Main Library", markings: "Sticker 'Code or Die' on lid", image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&q=70", status: "due" },
  { id: "LF-1039", name: "Blue Water Bottle", color: "Blue", category: "Personal", dateLost: daysAgo(92), location: "Gazebo", markings: "Dent on the base", image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=400&q=70", status: "due" },
  { id: "LF-1031", name: "Casio Calculator", color: "White", category: "Stationery", dateLost: daysAgo(91), location: "LT 3", markings: "Name 'A. Mwangi' on back", image: "https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=400&q=70", status: "due" },
  { id: "LF-1027", name: "Grey Beanie", color: "Grey", category: "Clothing", dateLost: daysAgo(90), location: "F4", markings: "Small hole on the seam", image: "https://images.unsplash.com/photo-1576871337622-98d48d1cf531?w=400&q=70", status: "due" },
  // Approaching the 90-day cut-off (83–89d) → triggers the "one week to disposal" alert
  { id: "LF-1026", name: "Denim Jacket", color: "Blue", category: "Clothing", dateLost: daysAgo(86), location: "F2", markings: "Enamel pin on collar", image: "https://images.unsplash.com/photo-1543076447-215ad9ba6923?w=400&q=70", status: "active" },
  { id: "LF-1024", name: "White Earbuds Case", color: "White", category: "Electronics", dateLost: daysAgo(84), location: "STMB Library", markings: "Left bud only", image: "https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?w=400&q=70", status: "active" },
  // Within the 3-month window but not yet 90 → YELLOW (will still be disposed this cycle)
  { id: "LF-1025", name: "Brown Leather Wallet", color: "Brown", category: "Personal", dateLost: daysAgo(78), location: "Student Centre", markings: "Empty, no ID inside", image: "https://images.unsplash.com/photo-1627123424574-724758594e93?w=400&q=70", status: "active" },
  { id: "LF-1018", name: "Red Hoodie (M)", color: "Red", category: "Clothing", dateLost: daysAgo(70), location: "MSB 13", markings: "Strathmore crest on chest", image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=400&q=70", status: "active" },
  { id: "LF-1017", name: "USB-C Charger", color: "White", category: "Electronics", dateLost: daysAgo(66), location: "STMB Library", markings: "20W, no cable", image: "https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=400&q=70", status: "active" },
  { id: "LF-1011", name: "AirPods Pro Case", color: "White", category: "Electronics", dateLost: daysAgo(58), location: "STMB Basement", markings: "Scratched lid", image: "https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?w=400&q=70", status: "active" },
  { id: "LF-1010", name: "Black Backpack", color: "Black", category: "Bags", dateLost: daysAgo(52), location: "LT 6", markings: "Adidas, missing side pocket", image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&q=70", status: "active" },
  { id: "LF-1009", name: "Textbook — Calculus", color: "Blue", category: "Stationery", dateLost: daysAgo(45), location: "MSB 7", markings: "Name 'J. Otieno' inside cover", image: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&q=70", status: "active" },
  { id: "LF-1008", name: "Reading Glasses", color: "Tortoise", category: "Accessories", dateLost: daysAgo(38), location: "Main Library", markings: "Cracked left arm", image: "https://images.unsplash.com/photo-1508296695146-257a814070b4?w=400&q=70", status: "active" },
  // Fresh — comfortably inside the window (default/no chip)
  { id: "LF-1007", name: "Spiral Notebook", color: "Yellow", category: "Stationery", dateLost: daysAgo(21), location: "F2", markings: "Course notes BBIT 2.2", image: "https://images.unsplash.com/photo-1531346878377-a5be20888e57?w=400&q=70", status: "active" },
  { id: "LF-1004", name: "Silver Wrist Watch", color: "Silver", category: "Accessories", dateLost: daysAgo(14), location: "Oval Building", markings: "Cracked glass, leather strap", image: "https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=400&q=70", status: "active" },
  { id: "LF-1001", name: "Black Umbrella", color: "Black", category: "Personal", dateLost: daysAgo(6), location: "F5", markings: "Bent rib, wooden handle", image: "https://images.unsplash.com/photo-1534103362078-d8e6184f0d7d?w=400&q=70", status: "active" },
];

export const daysSince = (iso: string) => {
  const ms = Date.now() - new Date(iso).getTime();
  return Math.floor(ms / (1000 * 60 * 60 * 24));
};

// Classify an item by how close it is to disposal.
export const ageBand = (iso: string): AgeBand => {
  const d = daysSince(iso);
  if (d >= 90) return "due";
  if (d >= 30) return "within_quarter";
  return "fresh";
};

export const statusLabel: Record<DisposalStatus, string> = {
  active: "In Custody",
  due: "Disposal Due (90+ days)",
  notice_sent: "Notice Sent",
  awaiting_pickup: "Awaiting Pickup",
  donated: "Donated",
};

// Prior disposal handovers grouped by cycle for the audit log.
export interface AuditBatch {
  id: string;
  cycleLabel: string;   // e.g. "Jan – March"
  releasedOn: string;   // ISO date
  officer: string;
  items: {
    id: string;
    name: string;
    color: string;
    category: string;
    dateLost: string;
    location: string;
    markings: string;
  }[];
}

export const AUDIT_BATCHES: AuditBatch[] = [
  {
    id: "B-014",
    cycleLabel: "Jan – March",
    releasedOn: daysAgo(180),
    officer: "admin@strathmore.edu",
    items: [
      { id: "LF-0921", name: "Grey Hoodie", color: "Grey", category: "Clothing", dateLost: daysAgo(275), location: "MSB 13", markings: "Nike logo, small tear on cuff" },
      { id: "LF-0918", name: "Scientific Calculator", color: "Black", category: "Stationery", dateLost: daysAgo(272), location: "LT 3", markings: "Sticker 'BBIT 1.1'" },
      { id: "LF-0905", name: "Reading Glasses", color: "Tortoise", category: "Accessories", dateLost: daysAgo(268), location: "Main Library", markings: "Cracked left arm" },
      { id: "LF-0894", name: "Blue Backpack", color: "Blue", category: "Bags", dateLost: daysAgo(261), location: "Oval Building", markings: "Adidas, missing side pocket" },
    ],
  },
  {
    id: "B-013",
    cycleLabel: "Oct – December",
    releasedOn: daysAgo(272),
    officer: "admin@strathmore.edu",
    items: [
      { id: "LF-0871", name: "White Earbuds", color: "White", category: "Electronics", dateLost: daysAgo(365), location: "STMB Library", markings: "Left bud only" },
      { id: "LF-0864", name: "Silver Water Bottle", color: "Silver", category: "Personal", dateLost: daysAgo(361), location: "Gazebo", markings: "Deep dent near cap" },
      { id: "LF-0852", name: "Denim Jacket", color: "Blue", category: "Clothing", dateLost: daysAgo(354), location: "F4", markings: "Enamel pin on collar" },
    ],
  },
  {
    id: "B-012",
    cycleLabel: "Jul – September",
    releasedOn: daysAgo(365),
    officer: "admin@strathmore.edu",
    items: [
      { id: "LF-0803", name: "Green Umbrella", color: "Green", category: "Personal", dateLost: daysAgo(455), location: "Student Centre", markings: "Wooden handle" },
      { id: "LF-0798", name: "USB-C Charger", color: "White", category: "Electronics", dateLost: daysAgo(451), location: "STMB Basement", markings: "20W Apple, no cable" },
      { id: "LF-0790", name: "Yellow Cap", color: "Yellow", category: "Clothing", dateLost: daysAgo(447), location: "F5", markings: "Strathmore Alumni print" },
      { id: "LF-0781", name: "Textbook — Calculus", color: "Blue", category: "Stationery", dateLost: daysAgo(440), location: "MSB 7", markings: "Name 'J. Otieno' inside cover" },
      { id: "LF-0774", name: "Rain Jacket", color: "Navy", category: "Clothing", dateLost: daysAgo(435), location: "Main Library", markings: "Reflective strip on back" },
    ],
  },
];
