import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronDown, ChevronRight, Package, User, Calendar } from "lucide-react";
import { Shell } from "@/components/Shell";
import { AUDIT_BATCHES } from "@/lib/mock-data";

export const Route = createFileRoute("/audit")({
  head: () => ({ meta: [{ title: "Audit Log · L&F Disposal" }] }),
  component: Audit,
});

function Audit() {
  const [openId, setOpenId] = useState<string | null>(AUDIT_BATCHES[0]?.id ?? null);

  return (
    <Shell>
      <div className="mx-auto max-w-5xl px-6 py-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Audit log · Disposal handovers</h1>
          <p className="text-sm text-muted-foreground">
            Every cycle of items released to the Community Outreach Club, grouped by the period they covered.
            Click a batch to see the full list of items that were handed over.
          </p>
        </div>

        <div className="space-y-3">
          {AUDIT_BATCHES.map((b) => {
            const open = openId === b.id;
            return (
              <div key={b.id} className="rounded-lg border bg-card overflow-hidden">
                <button
                  onClick={() => setOpenId(open ? null : b.id)}
                  className="w-full flex items-center justify-between p-4 hover:bg-secondary/40 text-left"
                >
                  <div className="flex items-center gap-3">
                    {open ? <ChevronDown className="w-4 h-4 text-muted-foreground" /> : <ChevronRight className="w-4 h-4 text-muted-foreground" />}
                    <div>
                      <div className="font-semibold">
                        {b.cycleLabel} items — released to Community Outreach
                      </div>
                      <div className="text-xs text-muted-foreground flex flex-wrap gap-x-4 gap-y-1 mt-1">
                        <span className="inline-flex items-center gap-1"><Calendar className="w-3 h-3" /> {b.releasedOn}</span>
                        <span className="inline-flex items-center gap-1"><User className="w-3 h-3" /> {b.officer}</span>
                        <span className="inline-flex items-center gap-1"><Package className="w-3 h-3" /> {b.items.length} items</span>
                        <span className="font-mono">Batch #{b.id}</span>
                      </div>
                    </div>
                  </div>
                  <span className="text-xs px-2 py-1 rounded-md bg-success/10 text-success-foreground border border-success/30">
                    Handed over
                  </span>
                </button>

                {open && (
                  <div className="border-t overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-secondary/50 text-muted-foreground">
                        <tr className="text-left">
                          <th className="px-4 py-2 font-medium">ID</th>
                          <th className="px-4 py-2 font-medium">Item</th>
                          <th className="px-4 py-2 font-medium">Color</th>
                          <th className="px-4 py-2 font-medium">Category</th>
                          <th className="px-4 py-2 font-medium">Date lost</th>
                          <th className="px-4 py-2 font-medium">Location</th>
                          <th className="px-4 py-2 font-medium">Markings</th>
                        </tr>
                      </thead>
                      <tbody>
                        {b.items.map((i) => (
                          <tr key={i.id} className="border-t">
                            <td className="px-4 py-2 font-mono text-xs text-muted-foreground">{i.id}</td>
                            <td className="px-4 py-2 font-medium">{i.name}</td>
                            <td className="px-4 py-2">{i.color}</td>
                            <td className="px-4 py-2">{i.category}</td>
                            <td className="px-4 py-2 text-muted-foreground">{i.dateLost}</td>
                            <td className="px-4 py-2">{i.location}</td>
                            <td className="px-4 py-2 text-muted-foreground">{i.markings}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </Shell>
  );
}
