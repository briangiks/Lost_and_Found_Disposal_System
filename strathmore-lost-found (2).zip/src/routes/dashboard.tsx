import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search, Filter, AlertTriangle, Send, ImageIcon, ArrowUpRight, Gift, Clock } from "lucide-react";
import { Shell } from "@/components/Shell";
import { MOCK_ITEMS, daysSince, ageBand, TOTAL_IN_CUSTODY, TOTAL_TO_DISPOSE, STRATH_LOCATIONS } from "@/lib/mock-data";

export const Route = createFileRoute("/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard · L&F Disposal" }] }),
  component: Dashboard,
});

const CATEGORIES = ["All", "Electronics", "Personal", "Clothing", "Stationery", "Accessories", "Bags"];

const uniq = (arr: string[]) => ["All", ...Array.from(new Set(arr))];

function Dashboard() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const [color, setColor] = useState("All");
  const [location, setLocation] = useState("All");
  const [markings, setMarkings] = useState("");
  const [dateLost, setDateLost] = useState("");

  const colorOpts = useMemo(() => uniq(MOCK_ITEMS.map((i) => i.color)), []);
  const locationOpts = useMemo(() => ["All", ...STRATH_LOCATIONS], []);

  const dueItems = MOCK_ITEMS.filter((i) => daysSince(i.dateLost) >= 90);
  const approachingItems = MOCK_ITEMS.filter((i) => {
    const d = daysSince(i.dateLost);
    return d >= 83 && d < 90;
  });

  const filtered = useMemo(() => {
    return MOCK_ITEMS.filter((i) => {
      if (cat !== "All" && i.category !== cat) return false;
      if (color !== "All" && i.color !== color) return false;
      if (location !== "All" && i.location !== location) return false;
      if (markings.trim() && !i.markings.toLowerCase().includes(markings.toLowerCase())) return false;
      if (dateLost && i.dateLost !== dateLost) return false;
      if (q.trim()) {
        const t = q.toLowerCase();
        if (!(`${i.name} ${i.color} ${i.location} ${i.markings} ${i.id}`).toLowerCase().includes(t)) return false;
      }
      return true;
    });
  }, [q, cat, color, location, markings, dateLost]);

  return (
    <Shell>
      <div className="mx-auto max-w-7xl px-6 py-6 space-y-6">
        {/* Alert 1 — one-week early warning */}
        {approachingItems.length > 0 && (
          <div className="rounded-lg border border-warning/40 bg-warning/10 p-4 flex items-start gap-3">
            <Clock className="w-5 h-5 text-warning-foreground shrink-0 mt-0.5" />
            <div className="flex-1">
              <div className="font-semibold text-warning-foreground">
                One week to the disposal cut-off · {approachingItems.length} item{approachingItems.length > 1 ? "s" : ""} approaching
              </div>
              <p className="text-sm text-muted-foreground">
                Please email Strathmore Communications to remind students to collect their items from
                the Lost &amp; Found office within the next 7 days before the quarterly disposal.
              </p>
            </div>
            <Link
              to="/disposal"
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-brand-blue text-white text-sm font-medium hover:opacity-95"
            >
              <Send className="w-4 h-4" /> Email Communications
            </Link>
          </div>
        )}

        {/* Alert 2 — quarterly disposal ready */}
        {dueItems.length > 0 && (
          <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-4 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
            <div className="flex-1">
              <div className="font-semibold text-destructive">
                Quarterly disposal ready · this quarter's unclaimed items are due for handover
              </div>
              <p className="text-sm text-muted-foreground">
                Every three months all unclaimed items in custody are handed over to the Community
                Service (Outreach Club). Start the disposal workflow below.
              </p>
            </div>
            <Link
              to="/disposal"
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-destructive text-destructive-foreground text-sm font-medium hover:opacity-95"
            >
              <Gift className="w-4 h-4" /> Start disposal
            </Link>
          </div>
        )}

        {/* Stats — only two, as requested */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="rounded-lg border bg-card p-5">
            <div className="text-xs text-muted-foreground uppercase tracking-wide">Total items in custody</div>
            <div className="text-3xl font-bold mt-2 text-brand-blue">{TOTAL_IN_CUSTODY}</div>
            <div className="text-xs text-muted-foreground mt-1">Unclaimed items currently held this quarter.</div>
          </div>
          <div className="rounded-lg border bg-card p-5">
            <div className="text-xs text-muted-foreground uppercase tracking-wide">Total items to be disposed</div>
            <div className="text-3xl font-bold mt-2 text-destructive">{TOTAL_TO_DISPOSE}</div>
            <div className="text-xs text-muted-foreground mt-1">Items that have reached or passed the 90-day window.</div>
          </div>
        </div>

        {/* Filters */}
        <div className="rounded-lg border bg-card p-4 space-y-3">
          <div className="flex items-center gap-2 text-sm font-medium"><Filter className="w-4 h-4" /> Filters</div>
          <div className="grid md:grid-cols-12 gap-3">
            <div className="md:col-span-4 relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search item, ID, keyword…"
                className="w-full pl-9 pr-3 py-2 rounded-md border border-input bg-card text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            <select value={cat} onChange={(e) => setCat(e.target.value)} className="md:col-span-2 px-3 py-2 rounded-md border border-input bg-card text-foreground text-sm" aria-label="Item category">
              {CATEGORIES.map((c) => <option key={c} value={c}>{c === "All" ? "All items" : c}</option>)}
            </select>
            <select value={color} onChange={(e) => setColor(e.target.value)} className="md:col-span-2 px-3 py-2 rounded-md border border-input bg-card text-foreground text-sm" aria-label="Color">
              {colorOpts.map((c) => <option key={c} value={c}>{c === "All" ? "All colors" : c}</option>)}
            </select>
            <select value={location} onChange={(e) => setLocation(e.target.value)} className="md:col-span-2 px-3 py-2 rounded-md border border-input bg-card text-foreground text-sm" aria-label="Location">
              {locationOpts.map((l) => <option key={l} value={l}>{l === "All" ? "All locations" : l}</option>)}
            </select>
            <input
              type="date"
              value={dateLost}
              onChange={(e) => setDateLost(e.target.value)}
              className="md:col-span-2 px-3 py-2 rounded-md border border-input bg-card text-foreground text-sm"
              aria-label="Date lost"
            />
            <input
              value={markings}
              onChange={(e) => setMarkings(e.target.value)}
              placeholder="Markings contain…"
              className="md:col-span-12 px-3 py-2 rounded-md border border-input bg-card text-foreground text-sm"
            />
          </div>
        </div>

        {/* Table */}
        <div className="rounded-lg border bg-card overflow-hidden">
          <div className="flex items-center justify-between p-4 border-b">
            <h2 className="font-semibold">Lost items registry</h2>
            <span className="text-xs text-muted-foreground">Showing {filtered.length} of {MOCK_ITEMS.length}</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-secondary/50 text-muted-foreground">
                <tr className="text-left">
                  <th className="px-4 py-3 font-medium">Photo</th>
                  <th className="px-4 py-3 font-medium">ID</th>
                  <th className="px-4 py-3 font-medium">Item</th>
                  <th className="px-4 py-3 font-medium">Color</th>
                  <th className="px-4 py-3 font-medium">Date lost</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">Location</th>
                  <th className="px-4 py-3 font-medium">Markings</th>
                  <th className="px-4 py-3 font-medium"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((i) => {
                  const band = ageBand(i.dateLost);
                  const age = daysSince(i.dateLost);
                  return (
                    <tr key={i.id} className="border-t hover:bg-secondary/30">
                      <td className="px-4 py-3">
                        {i.image ? (
                          <img src={i.image} alt={i.name} className="w-12 h-12 rounded-md object-cover border" />
                        ) : (
                          <div className="w-12 h-12 rounded-md border bg-secondary flex items-center justify-center"><ImageIcon className="w-4 h-4 text-muted-foreground" /></div>
                        )}
                      </td>
                      <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{i.id}</td>
                      <td className="px-4 py-3 font-medium">{i.name}</td>
                      <td className="px-4 py-3">{i.color}</td>
                      <td className="px-4 py-3 text-muted-foreground">{i.dateLost}</td>
                      <td className="px-4 py-3">
                        <StatusChip band={band} age={age} />
                      </td>
                      <td className="px-4 py-3">{i.location}</td>
                      <td className="px-4 py-3 text-muted-foreground max-w-[220px] truncate" title={i.markings}>{i.markings}</td>
                      <td className="px-4 py-3 text-right">
                        <Link to="/item/$id" params={{ id: i.id }} className="inline-flex items-center gap-1 text-brand-blue hover:underline text-xs font-medium">
                          View <ArrowUpRight className="w-3 h-3" />
                        </Link>
                      </td>
                    </tr>
                  );
                })}
                {filtered.length === 0 && (
                  <tr><td colSpan={9} className="px-4 py-12 text-center text-muted-foreground">No items match these filters.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </Shell>
  );
}

function StatusChip({ band, age }: { band: "fresh" | "within_quarter" | "due"; age: number }) {
  if (band === "due") {
    return (
      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-destructive/15 text-destructive border border-destructive/40">
        Due · {age}d
      </span>
    );
  }
  if (band === "within_quarter") {
    return (
      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-warning/25 text-warning-foreground border border-warning/50">
        In quarter · {age}d
      </span>
    );
  }
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium bg-secondary text-muted-foreground border">
      Fresh · {age}d
    </span>
  );
}
