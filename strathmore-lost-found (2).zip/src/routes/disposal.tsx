import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CheckCircle2, Circle, Mail, Clock, Gift, Send, AlertTriangle } from "lucide-react";
import { Shell } from "@/components/Shell";
import { MOCK_ITEMS, daysSince, TOTAL_TO_DISPOSE } from "@/lib/mock-data";

export const Route = createFileRoute("/disposal")({
  head: () => ({ meta: [{ title: "Disposal Workflow · L&F" }] }),
  component: DisposalWorkflow,
});

type Stage = 0 | 1 | 2 | 3;

const WEEK_MS = 7 * 24 * 3600 * 1000;

function formatLongDate(d: Date) {
  return d.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
}

function DisposalWorkflow() {
  const [stage, setStage] = useState<Stage>(0);
  const [handoverAt, setHandoverAt] = useState<number | null>(null); // ms timestamp when 7-day window ends
  const [now, setNow] = useState<number>(Date.now());
  const [toast, setToast] = useState<null | { title: string; note?: string }>(null);

  // Real 1s tick during countdown
  useEffect(() => {
    if (stage !== 2) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [stage]);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2400);
    return () => clearTimeout(t);
  }, [toast]);

  const dueItems = MOCK_ITEMS.filter((i) => daysSince(i.dateLost) >= 90);
  const handoverDate = handoverAt ? new Date(handoverAt) : new Date(Date.now() + WEEK_MS);
  const secondsLeft = handoverAt ? Math.max(0, Math.floor((handoverAt - now) / 1000)) : 7 * 24 * 3600;

  const fmt = (s: number) => {
    const days = Math.floor(s / (24 * 3600));
    const h = Math.floor((s % (24 * 3600)) / 3600).toString().padStart(2, "0");
    const m = Math.floor((s % 3600) / 60).toString().padStart(2, "0");
    const sec = Math.floor(s % 60).toString().padStart(2, "0");
    return `${days}d ${h}h ${m}m ${sec}s`;
  };

  return (
    <Shell>
      <div className="mx-auto max-w-6xl px-6 py-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Disposal workflow</h1>
          <p className="text-sm text-muted-foreground">
            Every three months, all unclaimed items in custody are handed over to the Community Outreach Club.
            Follow the steps below to complete this quarter's cycle.
          </p>
        </div>

        {/* Stepper */}
        <ol className="grid md:grid-cols-4 gap-3">
          <Step n={1} icon={<AlertTriangle className="w-4 h-4" />} title="Review this quarter's batch" active={stage === 0} done={stage > 0} />
          <Step n={2} icon={<Mail className="w-4 h-4" />} title="Email Strathmore Comms" active={stage === 1} done={stage > 1} />
          <Step n={3} icon={<Clock className="w-4 h-4" />} title="1-week student pickup window" active={stage === 2} done={stage > 2} />
          <Step n={4} icon={<Gift className="w-4 h-4" />} title="Release to Community Outreach" active={stage === 3} done={false} />
        </ol>

        {stage === 0 && (
          <Panel>
            <div className="flex items-center justify-between mb-3">
              <div>
                <h2 className="font-semibold">Step 1 · This quarter's disposal batch</h2>
                <p className="text-sm text-muted-foreground">
                  All unclaimed items from the past three months — {TOTAL_TO_DISPOSE} in total.
                  Preview below shows those already past the 90-day mark.
                </p>
              </div>
              <div className="text-sm">Batch <span className="font-mono">#B-015</span> · {TOTAL_TO_DISPOSE} items</div>
            </div>
            <ItemTable items={dueItems} />
            <div className="flex justify-end mt-4 gap-2">
              <button className="px-3 py-2 rounded-md border text-sm">Postpone batch</button>
              <button onClick={() => setStage(1)} className="px-4 py-2 rounded-md bg-brand-red text-white text-sm font-medium inline-flex items-center gap-2">
                <Send className="w-4 h-4" /> Notify &amp; prepare email
              </button>
            </div>
          </Panel>
        )}

        {stage === 1 && (
          <Panel>
            <h2 className="font-semibold">Step 2 · Email Strathmore Communications</h2>
            <p className="text-sm text-muted-foreground mb-4">A single general notice covers the entire batch — no per-item detail.</p>
            <div className="rounded-md border bg-secondary/40 p-4 text-sm space-y-2">
              <div><span className="text-muted-foreground">To:</span> communications@strathmore.edu</div>
              <div><span className="text-muted-foreground">CC:</span> lostandfound@strathmore.edu</div>
              <div><span className="text-muted-foreground">Subject:</span> Disposal Notice: Unclaimed Lost &amp; Found Items</div>
              <hr className="my-2" />
              <p>Dear Strathmore Communications team,</p>
              <p>
                The Lost &amp; Found office is preparing this quarter's disposal of unclaimed items.
                Kindly circulate a notice to all students today letting them know they have
                <strong> one week </strong> to come and check for any of their belongings at the
                Lost &amp; Found office.
              </p>
              <p>
                📍 <strong>Location:</strong> Central Building Phase 1 Basement — Lost &amp; Found Dept
              </p>
              <p>
                Any items not collected within the week will be handed over to the Community
                Outreach Club on <strong>{formatLongDate(handoverDate)}</strong> for disposal.
              </p>
              <p>Thank you,<br/>Lost &amp; Found Office</p>
            </div>
            <div className="flex justify-end mt-4 gap-2">
              <button onClick={() => setStage(0)} className="px-3 py-2 rounded-md border text-sm">Back</button>
              <button
                onClick={() => {
                  const target = Date.now() + WEEK_MS;
                  setHandoverAt(target);
                  setNow(Date.now());
                  setStage(2);
                  setToast({ title: "SENT", note: "Notice delivered to Strathmore Communications" });
                }}
                className="px-4 py-2 rounded-md bg-brand-red text-white text-sm font-medium inline-flex items-center gap-2"
              >
                <Mail className="w-4 h-4" /> Send email
              </button>
            </div>
          </Panel>
        )}

        {stage === 2 && (
          <Panel>
            <h2 className="font-semibold">Step 3 · One-week pickup window</h2>
            <p className="text-sm text-muted-foreground mb-4">
              Countdown started the moment the email was sent. Students have 7 days to collect their items
              from Central Building Phase 1 Basement — Lost &amp; Found Dept.
            </p>
            <div className="rounded-lg border bg-brand-blue/5 p-6 text-center">
              <div className="text-xs uppercase tracking-wider text-brand-blue font-semibold">Time remaining</div>
              <div className="text-5xl font-bold font-mono text-brand-blue-dark mt-2">{fmt(secondsLeft)}</div>
              <div className="text-xs text-muted-foreground mt-2">
                Handover scheduled for {formatLongDate(handoverDate)}
              </div>
            </div>
            <div className="grid sm:grid-cols-3 gap-3 mt-4 text-center">
              <Stat label="Items in batch" value={TOTAL_TO_DISPOSE} />
              <Stat label="Collected so far" value={4} />
              <Stat label="Still unclaimed" value={TOTAL_TO_DISPOSE - 4} />
            </div>
            <div className="flex justify-end mt-4 gap-2">
              <button onClick={() => setStage(3)} className="px-4 py-2 rounded-md bg-brand-red text-white text-sm font-medium">Skip wait (demo) →</button>
            </div>
          </Panel>
        )}

        {stage === 3 && (
          <Panel>
            <h2 className="font-semibold">Step 4 · Release to Community Outreach Club</h2>
            <p className="text-sm text-muted-foreground mb-4">
              The 1-week pickup window has elapsed. All remaining unclaimed items are ready for handover.
            </p>
            <div className="rounded-md border bg-secondary/40 p-4 text-sm space-y-2">
              <div><span className="text-muted-foreground">To:</span> outreach.club@strathmore.edu</div>
              <div><span className="text-muted-foreground">Subject:</span> Disposed items — handover for donation</div>
              <hr className="my-2" />
              <p>Hello Community Outreach Club,</p>
              <p>
                Please arrange collection today from the Lost &amp; Found office of this quarter's
                unclaimed items for onward donation.
              </p>
              <p>📍 Central Building Phase 1 Basement — Lost &amp; Found Dept</p>
              <p>Thank you for the partnership.</p>
            </div>
            <div className="mt-4 rounded-md border p-4 bg-card">
              <p className="text-sm text-muted-foreground">
                In total, <strong>{TOTAL_TO_DISPOSE - 4}</strong> items are being handed over as this quarter's
                disposal batch. These are general disposed items — the full manifest is stored in the audit log.
              </p>
            </div>
            <div className="flex justify-between items-center mt-4">
              <div className="inline-flex items-center gap-2 text-success-foreground text-sm">
                <CheckCircle2 className="w-4 h-4" /> Confirming will archive this batch and start the next 3-month cycle.
              </div>
              <div className="flex gap-2">
                <Link to="/audit" className="px-3 py-2 rounded-md border text-sm">View audit log</Link>
                <button
                  onClick={() => {
                    setToast({ title: "HANDED OVER", note: "Batch archived. Next quarterly cycle started." });
                    setStage(0);
                    setHandoverAt(null);
                  }}
                  className="px-4 py-2 rounded-md bg-brand-red text-white text-sm font-medium inline-flex items-center gap-2"
                >
                  <Gift className="w-4 h-4" /> Confirm handover
                </button>
              </div>
            </div>
          </Panel>
        )}
      </div>

      {/* Confirmation popup */}
      {toast && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 animate-in fade-in">
          <div className="bg-card rounded-2xl shadow-2xl p-8 w-[320px] text-center border">
            <div className="mx-auto w-16 h-16 rounded-full bg-success/15 border-4 border-success flex items-center justify-center">
              <CheckCircle2 className="w-9 h-9 text-success" />
            </div>
            <div className="mt-4 text-2xl font-bold tracking-wide text-success-foreground">{toast.title}</div>
            {toast.note && <p className="mt-2 text-sm text-muted-foreground">{toast.note}</p>}
          </div>
        </div>
      )}
    </Shell>
  );
}

function Step({ n, icon, title, active, done }: { n: number; icon: React.ReactNode; title: string; active: boolean; done: boolean }) {
  return (
    <li className={`rounded-lg border p-4 bg-card relative ${active ? "border-brand-red ring-2 ring-brand-red/20" : ""}`}>
      <div className="flex items-center gap-2">
        <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold ${done ? "bg-success text-success-foreground" : active ? "bg-brand-red text-white" : "bg-secondary text-muted-foreground"}`}>
          {done ? <CheckCircle2 className="w-4 h-4" /> : n}
        </div>
        <div className="text-xs text-muted-foreground inline-flex items-center gap-1">{icon} Step {n}</div>
      </div>
      <div className="mt-2 text-sm font-semibold">{title}</div>
      {!active && !done && <Circle className="absolute top-3 right-3 w-3 h-3 text-muted-foreground" />}
    </li>
  );
}

function Panel({ children }: { children: React.ReactNode }) {
  return <div className="rounded-lg border bg-card p-5">{children}</div>;
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-md border p-3">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="text-xl font-bold mt-1">{value}</div>
    </div>
  );
}

function ItemTable({ items }: { items: typeof MOCK_ITEMS }) {
  return (
    <div className="overflow-x-auto rounded-md border">
      <table className="w-full text-sm">
        <thead className="bg-secondary/50 text-muted-foreground">
          <tr className="text-left">
            <th className="px-3 py-2 font-medium">Photo</th>
            <th className="px-3 py-2 font-medium">ID</th>
            <th className="px-3 py-2 font-medium">Item</th>
            <th className="px-3 py-2 font-medium">Color</th>
            <th className="px-3 py-2 font-medium">Lost</th>
            <th className="px-3 py-2 font-medium">Age</th>
            <th className="px-3 py-2 font-medium">Location</th>
          </tr>
        </thead>
        <tbody>
          {items.map((i) => {
            const age = Math.max(90, daysSince(i.dateLost));
            return (
              <tr key={i.id} className="border-t">
                <td className="px-3 py-2"><img src={i.image} alt="" className="w-10 h-10 rounded object-cover border" /></td>
                <td className="px-3 py-2 font-mono text-xs">{i.id}</td>
                <td className="px-3 py-2 font-medium">{i.name}</td>
                <td className="px-3 py-2">{i.color}</td>
                <td className="px-3 py-2 text-muted-foreground">{i.dateLost}</td>
                <td className="px-3 py-2 text-destructive font-semibold">{age}d</td>
                <td className="px-3 py-2">{i.location}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
