import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Shell } from "@/components/Shell";

export const Route = createFileRoute("/emails")({
  head: () => ({ meta: [{ title: "Email Preview · L&F Disposal" }] }),
  component: EmailPreview,
});

const TABS = ["To Strathmore Comms", "To Students (drafted by Comms)", "To Community Outreach"] as const;

function EmailPreview() {
  const [tab, setTab] = useState<(typeof TABS)[number]>("To Strathmore Comms");
  const handoverDate = useMemo(() => {
    const d = new Date(Date.now() + 7 * 24 * 3600 * 1000);
    return d.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  }, []);

  return (
    <Shell>
      <div className="mx-auto max-w-4xl px-6 py-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Email templates</h1>
          <p className="text-sm text-muted-foreground">Auto-generated drafts sent during a quarterly disposal cycle.</p>
        </div>

        <div className="flex gap-2 border-b">
          {TABS.map((t) => (
            <button key={t} onClick={() => setTab(t)} className={`px-3 py-2 text-sm font-medium border-b-2 -mb-px ${tab === t ? "border-brand-red text-brand-red" : "border-transparent text-muted-foreground hover:text-foreground"}`}>
              {t}
            </button>
          ))}
        </div>

        <div className="rounded-lg border bg-card overflow-hidden">
          <div className="border-b bg-secondary/40 p-4 text-sm space-y-1">
            {tab === "To Strathmore Comms" && (
              <>
                <Row k="From" v="lostandfound@strathmore.edu" />
                <Row k="To" v="communications@strathmore.edu" />
                <Row k="Subject" v="Disposal Notice: Unclaimed Lost & Found Items" />
              </>
            )}
            {tab === "To Students (drafted by Comms)" && (
              <>
                <Row k="From" v="communications@strathmore.edu" />
                <Row k="To" v="students@strathmore.edu" />
                <Row k="Subject" v="One week to collect your item from Lost & Found" />
              </>
            )}
            {tab === "To Community Outreach" && (
              <>
                <Row k="From" v="lostandfound@strathmore.edu" />
                <Row k="To" v="outreach.club@strathmore.edu" />
                <Row k="Subject" v="Disposed items — handover for donation" />
              </>
            )}
          </div>

          <div className="p-6 prose prose-sm max-w-none">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded bg-brand-red text-white grid place-content-center font-bold text-sm">S</div>
              <div className="font-semibold text-brand-blue-dark">Strathmore University</div>
            </div>

            {tab === "To Strathmore Comms" && (
              <>
                <p>Dear Strathmore Communications team,</p>
                <p>
                  The Lost &amp; Found office is preparing this quarter's disposal of unclaimed items.
                  Kindly circulate a notice to all students letting them know they have <strong>one week</strong>
                  to come and check for any of their belongings at the Lost &amp; Found office.
                </p>
                <p>📍 <strong>Location:</strong> Central Building Phase 1 Basement — Lost &amp; Found Dept</p>
                <p>
                  Any items not collected within the week will be handed over to the Community Outreach
                  Club on <strong>{handoverDate}</strong> for disposal.
                </p>
                <p>Best regards,<br/>Lost &amp; Found Office</p>
              </>
            )}
            {tab === "To Students (drafted by Comms)" && (
              <>
                <p>Dear Students,</p>
                <p>If you have lost an item on campus in the last three months, please pass by the Lost &amp; Found office to check for it. You have <strong>one week</strong> before this quarter's disposal.</p>
                <p>📍 Central Building Phase 1 Basement — Lost &amp; Found Dept · Mon–Fri, 9am–5pm</p>
                <p>Items not collected by <strong>{handoverDate}</strong> will be handed over to the Strathmore Community Outreach Club for disposal.</p>
                <p>Asante,<br/>Strathmore Communications</p>
              </>
            )}
            {tab === "To Community Outreach" && (
              <>
                <p>Hello Community Outreach Club,</p>
                <p>
                  Please arrange collection today of this quarter's unclaimed Lost &amp; Found items for
                  onward donation. These are general disposed items — the full manifest is stored in
                  the audit log.
                </p>
                <p>📍 Central Building Phase 1 Basement — Lost &amp; Found Dept</p>
                <p>Regards,<br/>Lost &amp; Found Office</p>
              </>
            )}

            <hr className="my-4" />
            <p className="text-xs text-muted-foreground">Strathmore University · Ole Sangale Road, Madaraka Estate, Nairobi</p>
          </div>
        </div>
      </div>
    </Shell>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return <div className="flex gap-2"><span className="text-muted-foreground w-16">{k}:</span><span className="font-medium">{v}</span></div>;
}
