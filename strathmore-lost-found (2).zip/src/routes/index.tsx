import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Lock, Mail, Eye, EyeOff, ShieldCheck, User } from "lucide-react";
import strathmoreLogo from "@/assets/strathmore-logo.png";
import loginCampus from "@/assets/login-campus.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Login · Strathmore Lost & Found Disposal System" },
      { name: "description", content: "Admin login for the Strathmore University Lost & Found Disposal System." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("admin@strathmore.edu");
  const [password, setPassword] = useState("Demo1234");
  const [showPwd, setShowPwd] = useState(false);

  return (
    <div className="min-h-screen grid lg:grid-cols-[1.1fr_1fr] bg-white relative overflow-hidden">
      {/* Left hero */}
      <div className="relative hidden lg:block">
        <img
          src={loginCampus}
          alt="Strathmore University campus — Oval Building"
          className="absolute inset-0 w-full h-full object-cover"
        />
        {/* soft top gradient so logo/title read */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/25 via-transparent to-transparent" />

        {/* Logo top-left */}
        <div className="relative z-10 flex items-center gap-3 p-8">
          <img src={strathmoreLogo} alt="Strathmore University" className="h-16 w-auto drop-shadow" />
          <div className="text-white leading-tight drop-shadow">
            <div className="text-lg font-semibold tracking-wide">Strathmore</div>
            <div className="text-[11px] tracking-[0.28em] text-white/90">UNIVERSITY</div>
          </div>
        </div>

        <div className="absolute z-10 bottom-32 left-10 right-10">
          <h1 className="text-white text-4xl xl:text-5xl font-bold leading-tight drop-shadow-lg">
            Lost and Found<br />Department
          </h1>
          <div className="mt-3 h-1 w-24 bg-brand-red rounded" />
          <p className="mt-4 text-white/95 text-base drop-shadow">
            Reuniting lost items<br />with their rightful owners.
          </p>
        </div>

        {/* Curved brand ribbon at the bottom */}
        <svg viewBox="0 0 800 200" preserveAspectRatio="none" className="absolute bottom-0 left-0 w-full h-40 z-0">
          <path d="M0,120 C250,20 550,220 800,80 L800,200 L0,200 Z" fill="hsl(var(--brand-red, 350 80% 45%))" style={{ fill: "var(--brand-red)" }} />
          <path d="M0,160 C250,60 550,260 800,120 L800,200 L0,200 Z" fill="hsl(var(--brand-blue-dark))" style={{ fill: "var(--brand-blue-dark)" }} />
        </svg>
      </div>

      {/* Right card */}
      <div className="flex items-center justify-center p-6 sm:p-10 bg-background relative" style={{ backgroundImage: "radial-gradient(circle at top right, #f1f5f9, var(--background))" }}>
        {/* dotted background accent */}
        <div className="pointer-events-none absolute inset-0 opacity-30" style={{ backgroundImage: "radial-gradient(circle, #cbd5e1 1px, transparent 1px)", backgroundSize: "22px 22px" }} />
        <form
          onSubmit={(e) => { e.preventDefault(); navigate({ to: "/dashboard" }); }}
          className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl p-8 sm:p-10 space-y-6 border"
        >
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 rounded-full bg-brand-red/10 flex items-center justify-center">
              <User className="w-8 h-8 text-brand-red" strokeWidth={2} />
            </div>
            <h2 className="mt-4 text-3xl font-bold">
              <span className="text-brand-blue-dark">Welcome </span>
              <span className="text-brand-red">Back!</span>
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              Sign in to access the Lost and Found System
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-semibold text-foreground">Email Address</label>
              <div className="mt-1 relative">
                <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-3 py-3 rounded-lg border border-input bg-white text-foreground focus:outline-none focus:ring-2 focus:ring-brand-red/40"
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-semibold text-foreground">Password</label>
              <div className="mt-1 relative">
                <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type={showPwd ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-3 rounded-lg border border-input bg-white text-foreground focus:outline-none focus:ring-2 focus:ring-brand-red/40"
                />
                <button
                  type="button"
                  onClick={() => setShowPwd((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                  aria-label="Toggle password visibility"
                >
                  {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center gap-2">
                <input type="checkbox" defaultChecked className="accent-brand-red w-4 h-4" />
                <span>Remember Me</span>
              </label>
              <a className="text-brand-red font-semibold hover:underline" href="#">Forgot Password?</a>
            </div>
          </div>

          <button
            type="submit"
            className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-brand-red text-white font-semibold hover:opacity-95 shadow-md"
          >
            <Lock className="w-4 h-4" /> Sign In
          </button>

          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <div className="flex-1 h-px bg-border" />
            <ShieldCheck className="w-4 h-4 text-brand-red" />
            <div className="flex-1 h-px bg-border" />
          </div>

          <div className="text-center space-y-1">
            <div className="inline-flex items-center gap-2 text-xs text-muted-foreground">
              <ShieldCheck className="w-3 h-3 text-brand-red" />
              Authorized staff only. All activities are monitored.
            </div>
            <div className="text-xs text-muted-foreground">© Strathmore University</div>
            <div className="text-[11px] text-muted-foreground pt-1">
              Or just <Link to="/dashboard" className="text-brand-blue underline">skip to dashboard</Link> (demo).
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
