import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, MapPin, Calendar, Tag, ScanSearch } from "lucide-react";
import { Shell } from "@/components/Shell";
import { StatusBadge } from "@/components/StatusBadge";
import { MOCK_ITEMS, daysSince } from "@/lib/mock-data";

export const Route = createFileRoute("/item/$id")({
  head: () => ({ meta: [{ title: "Item detail · L&F Disposal" }] }),
  component: ItemDetail,
  notFoundComponent: () => <Shell><div className="p-8">Item not found.</div></Shell>,
});

function ItemDetail() {
  const { id } = Route.useParams();
  const item = MOCK_ITEMS.find((i) => i.id === id);
  if (!item) return <Shell><div className="p-8">Item not found.</div></Shell>;
  const age = daysSince(item.dateLost);

  return (
    <Shell>
      <div className="mx-auto max-w-5xl px-6 py-6 space-y-6">
        <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="w-4 h-4" /> Back to dashboard
        </Link>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            <img src={item.image} alt={item.name} className="w-full aspect-square object-cover rounded-lg border" />
            <div className="mt-3 text-xs text-muted-foreground">Photo uploaded at intake (new field for the disposal system).</div>
          </div>

          <div className="md:col-span-2 space-y-4">
            <div>
              <div className="text-xs font-mono text-muted-foreground">{item.id}</div>
              <h1 className="text-2xl font-bold">{item.name}</h1>
              <div className="mt-2"><StatusBadge status={item.status} /></div>
            </div>

            <div className="grid sm:grid-cols-2 gap-3 text-sm">
              <Field icon={<Tag className="w-4 h-4" />} label="Color" value={item.color} />
              <Field icon={<Tag className="w-4 h-4" />} label="Category" value={item.category} />
              <Field icon={<Calendar className="w-4 h-4" />} label="Date lost" value={`${item.dateLost} (${age} days ago)`} highlight={age >= 90} />
              <Field icon={<MapPin className="w-4 h-4" />} label="Location" value={item.location} />
              <Field icon={<ScanSearch className="w-4 h-4" />} label="Special markings" value={item.markings} fullWidth />
            </div>

            <div className="rounded-lg border p-4 bg-secondary/40">
              <div className="text-sm font-medium mb-2">Disposal timeline</div>
              <ul className="text-sm space-y-1.5 text-muted-foreground">
                <li>• Day 0 — Item logged at L&amp;F intake desk.</li>
                <li>• Day 60 — Reminder posted on student noticeboard.</li>
                <li className={age >= 90 ? "text-destructive font-medium" : ""}>• Day 90 — Flagged for disposal review.</li>
                <li>• Day 90+24h — If unclaimed, released to Community Outreach Club.</li>
              </ul>
            </div>

            <div className="flex gap-2">
              <Link to="/disposal" className="px-3 py-2 rounded-md bg-brand-red text-white text-sm font-medium">Add to disposal batch</Link>
              <button className="px-3 py-2 rounded-md border text-sm">Mark as collected</button>
            </div>
          </div>
        </div>
      </div>
    </Shell>
  );
}

function Field({ icon, label, value, highlight, fullWidth }: { icon: React.ReactNode; label: string; value: string; highlight?: boolean; fullWidth?: boolean }) {
  return (
    <div className={`rounded-md border bg-card p-3 ${fullWidth ? "sm:col-span-2" : ""}`}>
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">{icon}{label}</div>
      <div className={`mt-1 font-medium ${highlight ? "text-destructive" : ""}`}>{value}</div>
    </div>
  );
}
